from django.apps import AppConfig


class FcuserConfig(AppConfig):
    name = 'fcuser'
